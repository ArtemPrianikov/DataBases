#
# TABLE STRUCTURE FOR: countries
#

DROP TABLE IF EXISTS `countries`;

CREATE TABLE `countries` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `countries` (`id`, `name`) VALUES (2, 'Albania');
INSERT INTO `countries` (`id`, `name`) VALUES (20, 'Andorra');
INSERT INTO `countries` (`id`, `name`) VALUES (3, 'Antigua and Barbuda');
INSERT INTO `countries` (`id`, `name`) VALUES (5, 'Australia');
INSERT INTO `countries` (`id`, `name`) VALUES (8, 'Brazil');
INSERT INTO `countries` (`id`, `name`) VALUES (12, 'Brunei Darussalam');
INSERT INTO `countries` (`id`, `name`) VALUES (1, 'Burkina Faso');
INSERT INTO `countries` (`id`, `name`) VALUES (13, 'Burundi');
INSERT INTO `countries` (`id`, `name`) VALUES (44, 'Colombia');
INSERT INTO `countries` (`id`, `name`) VALUES (22, 'Cuba');
INSERT INTO `countries` (`id`, `name`) VALUES (27, 'Dominica');
INSERT INTO `countries` (`id`, `name`) VALUES (17, 'Estonia');
INSERT INTO `countries` (`id`, `name`) VALUES (7, 'Fiji');
INSERT INTO `countries` (`id`, `name`) VALUES (41, 'Guernsey');
INSERT INTO `countries` (`id`, `name`) VALUES (6, 'Guyana');
INSERT INTO `countries` (`id`, `name`) VALUES (16, 'Iceland');
INSERT INTO `countries` (`id`, `name`) VALUES (14, 'Indonesia');
INSERT INTO `countries` (`id`, `name`) VALUES (32, 'Jordan');
INSERT INTO `countries` (`id`, `name`) VALUES (18, 'Libyan Arab Jamahiriya');
INSERT INTO `countries` (`id`, `name`) VALUES (10, 'Martinique');
INSERT INTO `countries` (`id`, `name`) VALUES (34, 'Mayotte');
INSERT INTO `countries` (`id`, `name`) VALUES (39, 'Mexico');
INSERT INTO `countries` (`id`, `name`) VALUES (4, 'Micronesia');
INSERT INTO `countries` (`id`, `name`) VALUES (15, 'Myanmar');
INSERT INTO `countries` (`id`, `name`) VALUES (40, 'Netherlands Antilles');
INSERT INTO `countries` (`id`, `name`) VALUES (19, 'Northern Mariana Islands');
INSERT INTO `countries` (`id`, `name`) VALUES (43, 'Oman');
INSERT INTO `countries` (`id`, `name`) VALUES (38, 'Pakistan');
INSERT INTO `countries` (`id`, `name`) VALUES (26, 'Palestinian Territory');
INSERT INTO `countries` (`id`, `name`) VALUES (23, 'Panama');
INSERT INTO `countries` (`id`, `name`) VALUES (28, 'Papua New Guinea');
INSERT INTO `countries` (`id`, `name`) VALUES (36, 'Poland');
INSERT INTO `countries` (`id`, `name`) VALUES (42, 'Romania');
INSERT INTO `countries` (`id`, `name`) VALUES (37, 'Saint Kitts and Nevis');
INSERT INTO `countries` (`id`, `name`) VALUES (31, 'Saint Lucia');
INSERT INTO `countries` (`id`, `name`) VALUES (29, 'Saint Pierre and Miquelon');
INSERT INTO `countries` (`id`, `name`) VALUES (9, 'Samoa');
INSERT INTO `countries` (`id`, `name`) VALUES (35, 'South Georgia and the South Sandwich Islands');
INSERT INTO `countries` (`id`, `name`) VALUES (45, 'Suriname');
INSERT INTO `countries` (`id`, `name`) VALUES (30, 'Svalbard & Jan Mayen Islands');
INSERT INTO `countries` (`id`, `name`) VALUES (11, 'Tanzania');
INSERT INTO `countries` (`id`, `name`) VALUES (24, 'Tokelau');
INSERT INTO `countries` (`id`, `name`) VALUES (21, 'Turkmenistan');
INSERT INTO `countries` (`id`, `name`) VALUES (25, 'Turks and Caicos Islands');
INSERT INTO `countries` (`id`, `name`) VALUES (33, 'United States of America');


